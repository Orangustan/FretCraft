// FRETCRAFT — Progression logic
// selNode, checkGates, flash, toast, popup helpers

// ═══════════════════════════════════════════════════
//  INTERACTIONS
// ═══════════════════════════════════════════════════
function selNode(id){ S.sel = id; renderCard(); renderTree(); }
