// FRETCRAFT — Panel renderers
// renderLeft, renderCard, renderHeader, renderAchs

// ═══════════════════════════════════════════════════
//  LEFT PANEL
// ═══════════════════════════════════════════════════
function renderLeft(){
  // Branches
  var bl = document.getElementById('branch-list');
  bl.innerHTML = BR.map(function(br){
    var done = NODES.filter(function(n){ return n.br===br.id && nState(n.id)==='done'; }).length;
    var total = NODES.filter(function(n){ return n.br===br.id; }).length;
    var pct = total ? Math.round(done/total*100) : 0;
    return '<div class="branch-item active">'+
      '<div class="b-dot" style="background:'+br.color+';color:'+br.color+'"></div>'+
      '<div style="flex:1;min-width:0">'+
        '<div style="display:flex;justify-content:space-between">'+
          '<span class="b-name">'+br.ico+' '+br.name+'</span>'+
          '<span class="b-prog">'+done+'/'+total+'</span>'+
        '</div>'+
        '<div class="b-bar"><div class="b-fill" style="width:'+pct+'%;background:'+br.color+';box-shadow:0 0 4px '+br.color+'40"></div></div>'+
      '</div></div>';
  }).join('');

  // Next up — one per branch, first reachable
  var nl = document.getElementById('next-list');
  var suggestions = [];
  BR.forEach(function(br){
    var brNodes = NODES.filter(function(n){ return n.br===br.id && !n.gate; })
                       .sort(function(a,b){ return a.y - b.y; }); // sort by y (root=-0, higher=-more)
    for (var i=0; i<brNodes.length; i++){
      var n = brNodes[i]; var ns = nState(n.id);
      if (ns==='prog'){ suggestions.push({n:n,br:br}); break; }
      if (ns==='locked' && prereqsDone(n)){ suggestions.push({n:n,br:br}); break; }
    }
  });
  nl.innerHTML = suggestions.map(function(s){
    return '<div class="next-item" onclick="selNode(\''+s.n.id+'\')" style="border-color:'+s.br.color+'22">'+
      '<div class="ni-ico">'+s.n.ico+'</div>'+
      '<div class="ni-text">'+
        '<div class="ni-verb" style="color:'+s.br.color+'">'+s.n.verb+'</div>'+
        '<div class="ni-name" style="color:'+s.br.color+'dd">'+s.n.name+'</div>'+
        '<div class="ni-branch">'+s.br.name+'</div>'+
      '</div></div>';
  }).join('');

  // Song goals from archetype
  var lp = document.getElementById('branch-list').closest('.tree-sidebar') || document.getElementById('branch-list').closest('.lp');
  var oldSongs = lp.querySelector('#song-goals-sec');
  if (oldSongs) oldSongs.remove();
  var songs = S.archSongs || [];
  if (songs.length){
    var arch = ARCHETYPES.find(function(a){ return a.id===S.archetype; });
    var ac = arch ? arch.color : 'var(--gold)';
    var sg = document.createElement('div');
    sg.id = 'song-goals-sec';
    sg.className = 'panel-sec';
    var sh = '<div class="sec-label">Song Goals</div>';
    songs.forEach(function(song){
      var met2 = song.nodes.filter(function(nid){ return nState(nid)==='done'; }).length;
      var tot2 = song.nodes.length;
      var pct2 = Math.round(met2/tot2*100);
      sh += '<div style="margin-bottom:.45rem;cursor:pointer" onclick="highlightSongNodes('+JSON.stringify(song.nodes)+')" title="Highlight required skills on tree">'+
        '<div style="font-size:.62rem;color:var(--t1);font-weight:600;margin-bottom:.08rem">'+song.title+'</div>'+
        '<div style="font-size:.5rem;color:var(--t3);margin-bottom:.18rem">'+song.artist+'</div>'+
        '<div style="display:flex;align-items:center;gap:.4rem">'+
          '<div style="flex:1;height:3px;background:rgba(255,255,255,.06);border-radius:2px;overflow:hidden">'+
            '<div style="height:100%;width:'+pct2+'%;background:'+ac+';border-radius:2px;transition:width .4s"></div>'+
          '</div>'+
          '<span style="font-size:.5rem;color:'+ac+';font-weight:700;white-space:nowrap">'+pct2+'%</span>'+
        '</div></div>';
    });
    sg.innerHTML = sh;
    lp.appendChild(sg);
  }
}

// Highlight song required nodes on tree (adds a temporary pulse to those nodes)
function highlightSongNodes(nodeIds){
  S.songHighlight = nodeIds;
  renderTree();
  toast('🎵 Song path highlighted on constellation');
  setTimeout(function(){ S.songHighlight = null; renderTree(); }, 8000);
}

// ═══════════════════════════════════════════════════
//  RIGHT PANEL — NODE CARD
// ═══════════════════════════════════════════════════
function renderCard(){
  var el = document.getElementById('node-card');
  if (!S.sel){
    el.innerHTML = '<div class="nc-empty"><div class="nc-empty-ico">🌌</div>'+
      '<div style="font-size:.58rem;letter-spacing:.07em">Select a star to begin</div>'+
      '<div style="font-size:.5rem;color:rgba(200,168,75,.22);margin-top:.3rem;line-height:1.7">Larger stars = higher difficulty<br>Color marks the branch</div></div>';
    return;
  }
  var node = nById(S.sel); if (!node) return;
  var pts = S.pts[node.id] || 0;
  var pct = node.gate ? 0 : Math.min(100, Math.round(pts/node.max*100));
  var ns = nState(node.id);
  var bColor = branchColor(node.br);
  var lv = LV[node.l] || LV[0];
  var met = prereqsDone(node);

  var fillGrad = ns==='done'
    ? 'linear-gradient(90deg,rgba(0,0,0,.3),'+bColor+')'
    : 'linear-gradient(90deg,rgba(0,0,0,.3),rgba(200,168,75,.6))';

  el.innerHTML =
    '<div class="node-card">'+
    '<div class="nc-top">'+
      '<div class="nc-ico">'+node.ico+'</div>'+
      '<div>'+
        '<div class="nc-verb" style="color:'+bColor+'">'+node.verb+'</div>'+
        '<div class="nc-name">'+node.name+
          (S.archetype ? function(){
            var role=nodeRole(node.id);
            var label=role==='core'?'Core Path':role==='useful'?'Useful':'Optional';
            var cls='role-'+role;
            return ' <span class="role-badge '+cls+'">'+label+'</span>';
          }() : '')+
        '</div>'+
        '<div class="nc-meta">'+lv.name+' · '+lv.meta+'</div>'+
      '</div>'+
    '</div>'+
    '<div class="nc-branch-badge" style="background:'+bColor+'18;border-color:'+bColor+'50;color:'+bColor+'">'+
      '<span style="width:5px;height:5px;border-radius:50%;background:'+bColor+';box-shadow:0 0 4px '+bColor+';display:inline-block"></span>'+
      BR.find(function(b){return b.id===node.br;}).name+
    '</div>'+
    '<div class="nc-desc">'+node.desc+'</div>'+
    (node.gate
      ? '<div class="gate-status" style="background:'+bColor+'14;border:1px solid '+bColor+'40;color:'+(ns==='done'?bColor:'rgba(200,168,75,.5)')+'">'+
          (ns==='done'?'✦ Gate Cleared — Constellation Aligned':'⬡ Gate Locked — master surrounding stars to unlock')+'</div>'
      : '<div class="pts-block">'+
          '<div class="pts-row"><span class="pts-lbl">Mastery Points</span>'+
          '<span class="pts-val" style="color:'+(ns==='done'?bColor:ns==='prog'?'var(--gold)':'var(--t3)')+'">'+pts+'/'+node.max+'</span></div>'+
          '<div class="pts-track"><div class="pts-fill" style="width:'+pct+'%;background:'+fillGrad+'"></div></div>'+
          '<div class="pts-sub">'+pct+'% · '+(ns==='done'?'✦ Mastered':ns==='prog'?'In progress':met?'Ready to start':'Prerequisites not yet met')+'</div>'+
        '</div>')+
    '<div class="tips-label">Practice Tips</div>'+
    '<div class="tips">'+node.tips.map(function(t){
      return '<div class="tip"><span class="tip-arrow">→</span><span>'+t+'</span></div>';
    }).join('')+'</div></div>';

  document.getElementById('research-box').innerHTML =
    '<strong>📚 '+lv.name+' — Research Basis</strong>'+node.ref;
}

// ═══════════════════════════════════════════════════
//  HEADER
// ═══════════════════════════════════════════════════
function renderHeader(){
  document.getElementById('h-xp').textContent = S.xp.toLocaleString();
  var done = NODES.filter(function(n){ return !n.gate && nState(n.id)==='done'; }).length;
  document.getElementById('h-sk').textContent = done;
  document.getElementById('h-streak').textContent = S.streak;
  document.getElementById('h-rank').textContent = getRank().name;
  var topLv = 0;
  for (var l=4; l>=0; l--){
    if (NODES.filter(function(n){ return n.l===l && !n.gate; }).some(function(n){ return nState(n.id)==='done'; })){
      topLv=l; break;
    }
  }
  document.getElementById('h-level').textContent = LV[topLv].name;
}

function renderAchs(){
  var el = document.getElementById('achs-list');
  if (!S.achs.length){ el.innerHTML='<div class="ach-empty">Achievements appear here as you practice.</div>'; return; }
  el.innerHTML = S.achs.slice(-5).reverse().map(function(a){
    return '<div class="ach"><span class="ach-ico">'+a.ico+'</span><span class="ach-txt">'+a.txt+'</span><span class="ach-xp">+'+a.xp+'</span></div>';
  }).join('');
}
